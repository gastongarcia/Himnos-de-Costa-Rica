Junior
======

A framework for building HTML5 mobile apps with a native look and feel.
Check out the github page: http://justspamjustin.github.com/junior
